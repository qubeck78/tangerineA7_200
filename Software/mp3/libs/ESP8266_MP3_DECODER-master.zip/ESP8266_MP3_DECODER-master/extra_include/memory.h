#ifndef _MEMORY_H_
#define _MEMORY_H_

#ifndef	_STRING_H_
# include <string.h>
#endif	/* _STRING_H_ */

#endif	/* _MEMORY_H_ */
