char unalChar(char const *adr);
short unalShort(short const *adr);
